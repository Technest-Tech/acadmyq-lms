# Sprint 0 — Foundation & Project Setup

> **Status:** Detailed / Ready to execute
> **Depends on:** Nothing (first sprint)
> **Blocks:** All other sprints
> **References:** Master Spec §6 (Architecture), §6.3 (cross-cutting concerns)

---

## 1. Goal

Stand up a running, deployable, bilingual project skeleton with the chosen stack fully wired together — no business logic, but every architectural primitive in place and proven by a health check. This sprint exists to **de-risk the toolchain** before any domain code is written.

## 2. Scope

### In scope
- Next.js 15 (App Router) + TypeScript project initialization.
- Tailwind CSS + shadcn/ui configured, with a base theme matching the prototype's identity (emerald/gold, Noto Kufi Arabic).
- Supabase project: database + Auth provisioned, connection wired, env vars managed.
- next-intl configured with **Arabic (RTL, default)** and **English (LTR)**, including direction switching.
- Shared utility layer: money (integer minor units + currency), time (UTC storage helpers), and typed enums from Master Spec §9.
- Linting (ESLint), formatting (Prettier), strict TypeScript config.
- CI pipeline (typecheck + lint + test on PR).
- Deploy pipeline to Vercel with preview deployments.
- A `/health` route returning app + DB connectivity status.
- The empty authenticated-looking shell (sidebar/header) as static layout, bilingual.

### Out of scope (explicitly deferred)
- Any database tables beyond what Supabase creates by default (schema is Sprint 1).
- Real authentication logic / roles (Sprint 2).
- Any domain entity or CRUD.
- RLS policies (Sprint 1).

## 3. Tasks

1. **Repo & tooling**
   - Initialize monorepo-ready single app; pin Node version; configure pnpm/npm.
   - ESLint + Prettier + strict `tsconfig` (`strict: true`, `noUncheckedIndexedAccess: true`).
2. **Framework**
   - Next.js App Router scaffold; base layout; error and not-found boundaries.
3. **UI foundation**
   - Tailwind config with design tokens (colors, font family Noto Kufi Arabic, radius scale).
   - Install shadcn/ui; theme it to the tokens; verify a Button/Card render RTL.
4. **i18n**
   - next-intl setup; `ar` and `en` message catalogs; `dir` attribute switches with locale; locale switcher in header.
5. **Database/Auth provisioning**
   - Create Supabase project; store keys in env (`.env.local`, Vercel envs); typed Supabase client wrapper.
6. **Shared utilities**
   - `money.ts`: `Money { amountMinor: number; currency: ISO4217 }` + format/parse; no floats.
   - `time.ts`: UTC store/convert helpers; academy-timezone render helper.
   - `enums.ts`: export canonical enums from Master Spec §9.
7. **Health check**
   - `/health` server route: returns `{ app: "ok", db: "ok" | "error" }` by pinging Supabase.
8. **CI/CD**
   - GitHub Actions: install → typecheck → lint → test.
   - Vercel project linked; preview deploys on PR; production on main.
9. **App shell (static)**
   - Port the prototype's sidebar + header as a static, unauthenticated layout; bilingual labels; responsive + RTL verified.

## 4. Schema / Data deltas
None. (Schema begins in Sprint 1.) Supabase default `auth` schema is used as-is.

## 5. API surface
- `GET /health` → `200 { app, db, version, time }`.

## 6. Definition of Done / Acceptance Criteria
- **AC-0.1** App builds and deploys to Vercel; production URL loads.
- **AC-0.2** `/health` returns `db: "ok"` against the real Supabase instance.
- **AC-0.3** Switching locale flips both copy **and** layout direction (RTL↔LTR) across the shell.
- **AC-0.4** Default locale is Arabic and the shell renders RTL by default.
- **AC-0.5** CI runs typecheck + lint + test and is green on the main branch.
- **AC-0.6** `money.ts` rejects float construction and round-trips an amount without precision loss.
- **AC-0.7** `time.ts` stores a known local time as correct UTC and renders it back in a given timezone.
- **AC-0.8** shadcn/ui components render correctly mirrored in RTL (no clipped icons/padding).
- **AC-0.9** Strict TypeScript passes with zero `any` in shared utilities.

## 7. Test Cases

> Test IDs are stable and referenced in CI. Format: `TC-0.<n>`. Each maps to one or more acceptance criteria.

### Unit — money utility
- **TC-0.1** Given `Money(1500, "EGP")`, formatting in `ar` yields the Arabic-numeral amount with the EGP symbol. *(AC-0.6)*
- **TC-0.2** Constructing `Money` from a float (e.g. `15.0`) throws / is rejected by the type system. *(AC-0.6)*
- **TC-0.3** Adding `Money(1000,"EGP") + Money(500,"EGP")` = `Money(1500,"EGP")`. *(AC-0.6)*
- **TC-0.4** Adding two `Money` of different currencies throws. *(AC-0.6, R-INV-7)*
- **TC-0.5** Parsing "1,500.50" in a 2-decimal currency yields `amountMinor = 150050`. *(AC-0.6)*

### Unit — time utility
- **TC-0.6** A local time `2026-06-10 18:00` in `Africa/Cairo` stores as the correct UTC instant. *(AC-0.7)*
- **TC-0.7** A stored UTC instant renders back to the correct wall-clock time in `Asia/Riyadh`. *(AC-0.7)*
- **TC-0.8** A DST-affected timezone round-trips a time across a DST boundary without drift. *(AC-0.7)*

### Integration — health & DB
- **TC-0.9** `GET /health` returns `200` with `app: "ok"`. *(AC-0.1)*
- **TC-0.10** `GET /health` returns `db: "ok"` when Supabase is reachable. *(AC-0.2)*
- **TC-0.11** With DB credentials broken, `/health` returns `db: "error"` and a non-200 or flagged payload (degraded, not crashed). *(AC-0.2)*

### UI / i18n
- **TC-0.12** On first load with no locale set, the document `dir` is `rtl` and language is Arabic. *(AC-0.4)*
- **TC-0.13** Selecting English sets `dir="ltr"`, swaps all visible shell strings, and persists the choice. *(AC-0.3)*
- **TC-0.14** Selecting Arabic returns to `dir="rtl"` and Arabic strings. *(AC-0.3)*
- **TC-0.15** A shadcn Button with a leading icon mirrors icon placement correctly in RTL (icon on the right). *(AC-0.8)*
- **TC-0.16** The shell is usable at 360px width (mobile): sidebar collapses, no horizontal scroll. *(AC-0.8)*

### Pipeline
- **TC-0.17** A PR introducing a type error fails CI at the typecheck step. *(AC-0.5)*
- **TC-0.18** A PR introducing a lint violation fails CI at the lint step. *(AC-0.5)*
- **TC-0.19** Merging to main triggers a production Vercel deploy that passes the smoke test (`/health` 200). *(AC-0.1, AC-0.5)*

## 8. Risks & mitigations
- **Risk:** next-intl RTL/LTR switching interacting badly with shadcn/ui defaults. **Mitigation:** verify with TC-0.15 early; isolate direction logic in the root layout.
- **Risk:** Money/time conventions adopted inconsistently later. **Mitigation:** lint rule banning raw `number` for currency in domain code (added when domain code starts, Sprint 1).

## 9. Estimate
Small–Medium. This is plumbing; the value is in getting conventions right so later sprints move fast.
